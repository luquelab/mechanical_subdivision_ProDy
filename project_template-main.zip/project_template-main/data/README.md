# WHAT
This folder contains the raw data associated with the project and the potential references
