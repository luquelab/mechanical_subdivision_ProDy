# WHAT
This folder contains the results, performance analysis, and commented references associated with the project.
