# WHAT
This folder contains the manuscript, digital copies of the cited references, figures, and other associated files for publication. 
